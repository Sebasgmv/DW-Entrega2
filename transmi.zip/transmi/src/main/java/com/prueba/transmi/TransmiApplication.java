package com.prueba.transmi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransmiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransmiApplication.class, args);
	}
	
}
