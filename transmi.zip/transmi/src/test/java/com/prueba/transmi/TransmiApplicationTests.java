package com.prueba.transmi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransmiApplicationTests {

	@Test
	void contextLoads() {
	}

}
